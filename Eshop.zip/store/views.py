from django.shortcuts import render, redirect, HttpResponseRedirect
from .models import Product, Category, Customer, Order
from django.contrib.auth.hashers import make_password, check_password

# For Class Based View
from django.views import View

# Middleware only used for Orders Page
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator

# Create your views here.
def index (request):
    
    # print(products)
    categories = Category.get_all_categories()

    # print(request.GET) # in index.html we are using "/?category", same is read here.
    category_id = request.GET.get('category')
    if category_id:
        products = Product.get_all_products_by_id(category_id)
    else:
        products = Product.get_all_products()

    context = {
        'products' : products,
        'categories' : categories,
    }

    # CHeck for Session.
    print('Session : You are --> ', request.session.get('customer_email'))

    return render(request, 'store/index.html', context)

def signup(request): 
    if request.method == 'GET':
        return render (request, 'store/signup.html')
    else : 
        postData = request.POST
        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        email = postData.get('email')
        password = postData.get('password')

        customer = Customer(
                firstname = firstname,
                lastname = lastname,
                email = email,
                password = password
            )

        # Validation
        error_message = None

        if (not firstname):
            error_message = "First Name is required."
        elif len(firstname) < 3:
            error_message = 'First Name must be minimum of 3 Character long.'

        if customer.email_isExists():
            error_message = 'Email already taken, please try login.'

        # Saving the model
        if not error_message:
            customer.password = make_password(customer.password) # Encrypt or Hash the password.
            # customer.save() # Usual way of saving the data.
            customer.register() # calling the method from CUstomer model.

            return redirect('login')

        else: # Error found then go back to signup page.
            context = {
                'error' : error_message,
                'firstname' : firstname,
                'lastname' : lastname,
                'email' : email
            }
            return render (request, 'store/signup.html', context)

def login(request):
    if request.method == 'GET':
        return render (request, 'store/login.html')    
    else : 
        print("Post Method called")
        email = request.POST.get('email')
        password = request.POST.get('password')

        customer = Customer.get_customer_by_email(email)

        error_message = None

        if customer and check_password(password, customer.password) :
            print("Customer exists and password matched.")
            return redirect('home') 
        else : 
            print("Either Customer not exists or password mot matched.")
            error_message = 'Email or Password is invalid. Please try again'

        print("common else")
        context = {
                'error' : error_message,
                'email' : email
            }

        return render (request, 'store/login.html', context)            

# Class based View
class CBV_Login(View):
    return_url = None

    def get(self, request):
        CBV_Login.return_url = request.GET.get('return_url')
        return render (request, 'store/login.html')
    
    def post(self, request):
        # print("Post Method called")
        email = request.POST.get('email')
        password = request.POST.get('password')

        customer = Customer.get_customer_by_email(email)

        error_message = None

        if customer and check_password(password, customer.password) :
            # print("Customer exists and password matched.")
            
            # Create a Session
            # request.session['customer_id'] = customer.id
            # request.session['customer_email'] = customer.email
            request.session['customer'] = customer.id

            if CBV_Login.return_url:
                return HttpResponseRedirect(CBV_Login.return_url)
            else :
                CBV_Login.return_url = None
                return redirect('home') 
        else : 
            # print("Either Customer not exists or password mot matched.")
            error_message = 'Email or Password is invalid. Please try again'

        # print("common else")
        context = {
                'error' : error_message,
                'email' : email
            }

        return render (request, 'store/login.html', context) 

class CBV_Index(View):

    def post(self, request):
        product = request.POST.get('cart_product')
        remove = request.POST.get('cart_remove')

        # print('Product Selected by the Customer to add in cart', product)
        cart = request.session.get('cart')

        if cart : 
            qty = cart.get(product)

            if qty:
                if remove:
                    cart[product] = qty - 1
                    if qty == 1:
                        cart.pop(product)
                else:                   
                    cart[product] = qty + 1
            else:
                cart[product] = 1
        else :
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart

        print('Customer Cart --> ', request.session['cart'])

        return redirect('home')

    def get(self, request):  
        # print(products)
        categories = Category.get_all_categories()
        products = None

        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}

        # Clear the session
        # request.session.clear() # Will clear entire session
        # request.session.get('cart').clear # will just clear the cart.

        # print(request.GET) # in index.html we are using "/?category", same is read here.
        category_id = request.GET.get('category')
        if category_id:
            products = Product.get_all_products_by_id(category_id)
        else:
            products = Product.get_all_products()

        context = {
            'products' : products,
            'categories' : categories,
        }

        # CHeck for Session.
        # print('Session : You are --> ', request.session.get('customer_email'))
        print('Session : You are --> ', request.session.get('customer'))

        return render(request, 'store/index.html', context)

def logout(request):
    request.session.clear()

    return redirect('login')

class CBV_Cart(View):
    def get(self, request):
        # print(request.session.get('cart'))
        # print(request.session.get('cart').keys())
        # print(list(request.session.get('cart').keys()))

        ids = list(request.session.get('cart').keys())
        
        products = Product.get_products_by_ids(ids)

        # print(products)

        context = {
            'products' : products
        }

        return render (request, 'store/cart.html', context)  

class CBV_CheckOut(View):
    def post(self, request):
        shpAddress = request.POST.get('shpAddress') 
        shpPhone = request.POST.get('shpPhone') 
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_ids(list(cart.keys()))

        for p in products:
            order = Order(
                customer = Customer(id = customer), # passing the instance
                product = p,  # passing the instance
                price = p.price,
                shipping_address = shpAddress,
                phone = shpPhone,
                quantity = cart.get(str(p.id)) # key in cart is in string format.
            )
            order.placeOrder()

        request.session['cart'] = {}

        return redirect('home')

class CBV_Orders(View):
    @method_decorator(auth_middleware)
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer_id(customer)
        context = {'orders' : orders}

        return render(request, 'store/orders.html', context)         