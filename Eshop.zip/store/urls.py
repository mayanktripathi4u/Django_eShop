from django.urls import path
from .views import index, signup, login, CBV_Login, CBV_Index, logout, CBV_Cart, CBV_CheckOut, CBV_Orders
# from .middlewares.auth import auth_middleware

urlpatterns = [
    # path('', index, name = 'home'),
    path('signup', signup, name = 'signup'),
    # path('login', login, name = 'login'),
    path('logout', logout, name = 'logout'),

    # CLass Based View
    path('', CBV_Index.as_view(), name = 'home'),
    path('login', CBV_Login.as_view(), name = 'login'),
    path('cart', CBV_Cart.as_view(), name = 'cart'),
    path('check-out', CBV_CheckOut.as_view(), name = 'check-out'),
    path('orders', CBV_Orders.as_view(), name = 'orders'),
    # path('orders', auth_middleware(CBV_Orders.as_view()), name = 'orders'),
]